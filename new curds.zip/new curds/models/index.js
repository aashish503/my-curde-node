var mongoose= require('mongoose');
var newSchema= mongoose.Schema({
    name:String,
    email:String,
});
module.exports = mongoose.model('users',newSchema); 